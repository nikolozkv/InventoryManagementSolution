using InventoryManagementWebApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryManagementWebApp.Controllers
{
    [Authorize]
    public class Operations_SpiritsController : Controller
    {
        private readonly InventoryContext _context;

        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int id) ? id : 1;
        }

        public Operations_SpiritsController(InventoryContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Index(int barrelId)
        {
            var barrel = await _context.Barrels
                .Include(b => b.Company).ThenInclude(c => c.CompanyType)
                .Include(b => b.Beverage).ThenInclude(bv => bv.ProductType)
                .Include(b => b.Beverage).ThenInclude(bv => bv.Category)
                .Include(b => b.Beverage).ThenInclude(bv => bv.SubCategory)
                .Include(b => b.Beverage).ThenInclude(bv => bv.Color)
                .Include(b => b.Beverage).ThenInclude(bv => bv.Sweetness)
                .FirstOrDefaultAsync(b => b.BarrelID == barrelId);

            if (barrel == null)
                return NotFound("სპირტის კასრი ვერ მოიძებნა.");

            // თემის ფერი აიღე მიმდინარე კასრის სასმელის ტიპიდან
            ViewBag.CurrentThemeColor = barrel.Beverage?.ProductType?.ThemeColor ?? "#c9def3";

            // ვიღებთ სასმელის BitValue-ს (სპირტისთვის იქნება 4)
            // თუ რატომღაც ცარიელია, 0-ით დავაზღვევთ რომ ერორი არ ამოაგდოს
            // int productBitValue = 4; // ტესტისთვის, რომ დარწმუნდე ფილტრი მუშაობს. რეალურად უნდა იყოს სასმელის BitValue 
            // int productBitValue = barrel.ProductTypeBitValue is int pbv ? pbv : 0;

            // 1. DropDown-ისთვის განკუთვნილი სია
            // ✅ OperationDefinition ვიღებთ ბიტს კატეგორიიდან და არა პროდუქტის ტიპიდან
            int categoryBitValue = barrel.Beverage?.Category?.BitValue ?? 0;

            // 2. DropDown-ის სია (უკვე შეცვლილი გაქვს)
            ViewBag.OperationDefinitions = await _context.OperationDefinitions
                .Where(o => o.IsActive == true && (o.TypeCodeMask & categoryBitValue) > 0)
                .OrderBy(o => o.Position)
                .Select(o => new SelectListItem { Text = o.Name, Value = o.OperationDefID.ToString() })
                .ToListAsync();

            // 3. 🆕 JavaScript-ის სრული ობიექტი - აქაც categoryBitValue უნდა იყოს!
            ViewBag.OperationDefinitionsFull = await _context.OperationDefinitions
                .Where(o => o.IsActive == true && (o.TypeCodeMask & categoryBitValue) > 0)
                .Select(o => new { o.OperationDefID, o.Name, o.OperType, o.PreserveBarrelState })
                .ToListAsync();

            ViewBag.DocumentTypes = await _context.DocumentTypes
                .Where(d => d.IsActive)
                .Select(d => new SelectListItem { Text = d.DocumentName, Value = d.DocumentTypeID.ToString() })
                .ToListAsync();

            var operations = await _context.Operations
                    .Where(o => o.BarrelID == barrelId)
                    .Include(o => o.OperationDefinition)
                    .Include(o => o.DocumentType)
                    .Include(o => o.Barrel)
                    .Include(o => o.Beverage).ThenInclude(b => b.ProductType)
                    .Include(o => o.Beverage).ThenInclude(b => b.Category)
                    .Include(o => o.Beverage).ThenInclude(b => b.Color)
                    .Include(o => o.Beverage).ThenInclude(b => b.Sweetness)
                    .OrderByDescending(o => o.TransactionDate)
                    .ThenBy(o => o.CalcOrder)
                    .ThenByDescending(o => o.OperationID)
                    .ToListAsync();

            // 1. ოპერაციებიდან შემსრულებელი მომხმარებლების უნიკალური ID-ების ამოღება
            var userIds = operations.Where(o => o.ExecutedByUserID.HasValue)
                                   .Select(o => o.ExecutedByUserID.Value)
                                   .Distinct()
                                   .ToList();

            // 2. ოპერაციებიდან წყარო კომპანიების უნიკალური ID-ების ამოღება
            var sourceCompanyIds = operations.Where(o => o.SourceCompanyID.HasValue)
                                             .Select(o => o.SourceCompanyID.Value)
                                             .Distinct()
                                             .ToList();

            // 3. მომხმარებლების სახელების წამოღება (ახალი კავშირის გახსნის გარეშე, არსებული EF Context-ით)
            var userData = new Dictionary<int, (string, string)>();
            if (userIds.Any())
            {
                var conn = _context.Database.GetDbConnection();
                if (conn.State != ConnectionState.Open) await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                var userParams = string.Join(",", userIds);
                cmd.CommandText = $"SELECT UserID, FirstName, LastName FROM Users WHERE UserID IN ({userParams})";

                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    int uId = reader.GetInt32(reader.GetOrdinal("UserID"));
                    string fName = reader.IsDBNull(reader.GetOrdinal("FirstName")) ? "" : reader.GetString(reader.GetOrdinal("FirstName"));
                    string lName = reader.IsDBNull(reader.GetOrdinal("LastName")) ? "" : reader.GetString(reader.GetOrdinal("LastName"));
                    userData[uId] = (fName, lName);
                }
            }

            // 4. წყარო კომპანიების სახელების წამოღება
            var sourceCompanyData = new Dictionary<int, string>();
            if (sourceCompanyIds.Any())
            {
                var conn = _context.Database.GetDbConnection();
                if (conn.State != ConnectionState.Open) await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                var compParams = string.Join(",", sourceCompanyIds);
                cmd.CommandText = $"SELECT CompanyID, Name FROM Companies WHERE CompanyID IN ({compParams})";

                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    int cId = reader.GetInt32(reader.GetOrdinal("CompanyID"));
                    string cName = reader.IsDBNull(reader.GetOrdinal("Name")) ? "" : reader.GetString(reader.GetOrdinal("Name"));
                    sourceCompanyData[cId] = cName;
                }
            }

            var viewModel = new OperationsSpiritPageViewModel
            {
                BarrelID = barrel.BarrelID,
                CompanyID = barrel.CompanyID,
                CompanyName = barrel.Company.Name,
                CompanyTypeName = barrel.Company.CompanyType?.Name,
                CompanyLot = barrel.Company.CompanyLot,

                BeverageID = barrel.BeverageID,
                BeverageName = barrel.Beverage.Name,
                ProductType = barrel.Beverage.ProductType?.Name,
                Category = barrel.Beverage.Category?.Name,
                Color = barrel.Beverage.Color?.Name,
                Sweetness = barrel.Beverage.Sweetness?.Name,

                CurrentVolume = barrel.CurrentVolume, // ✅ დაემატა "m" 
                WeightedAvgDate = barrel.WeightedAvgDate,
                CurrentAlcPercent = barrel.CurrentAlcPercent,
                RealPercent = barrel.RealPercent,

                // ✅ გასწორდა Select-ის ლოგიკა (დაემატა ბლოკი { ... return new ... })
                Operations = operations.Select(o =>
                {
                    string firstName = "";
                    string lastName = "";
                    if (o.ExecutedByUserID.HasValue && userData.ContainsKey(o.ExecutedByUserID.Value))
                    {
                        var userInfo = userData[o.ExecutedByUserID.Value];
                        firstName = userInfo.Item1;
                        lastName = userInfo.Item2;
                    }

                    string sourceCompanyName = "";
                    if (o.SourceCompanyID.HasValue && sourceCompanyData.ContainsKey(o.SourceCompanyID.Value))
                    {
                        sourceCompanyName = sourceCompanyData[o.SourceCompanyID.Value];
                    }

                    return new OperationItemViewModel
                    {
                        OperationID = o.OperationID,
                        TransactionDate = o.TransactionDate,
                        OperName = o.OperName,
                        DocumentNumber = o.DocumentNumber,
                        DocumentTypeName = o.DocumentType?.DocumentName,
                        Quantity = (o.Math == "-" ? "-" : "+") + o.Quantity.ToString("### ### ##0.00"),
                        VolumeLeft = o.VolumeLeft,

                        BeverageName = (o.Beverage?.Name ?? "") +
                            // ✅ ღვინისთვის (BitValue 1, 2, 8)
                            ((o.Beverage?.ProductType?.BitValue & 11) > 0 ?
                                $" ({(o.HarvestYear > 0 ? o.HarvestYear.ToString() : (o.Barrel?.Year > 0 ? o.Barrel.Year.ToString() : "--"))})"
                            : "") +

                            // ✅ სპირტისთვის (BitValue 4, 16)
                            ((o.Beverage?.ProductType?.BitValue & 20) > 0 ?
                                $" ({(o.Barrel?.RealPercent > 0 ? o.Barrel.RealPercent?.ToString("0.##") : "--")}°)"
                            : ""),

                        ProductType = o.Beverage?.ProductType?.Name,
                        Category = o.Beverage?.Category?.Name,
                        Color = o.Beverage?.Color?.Name,
                        Sweetness = o.Beverage?.Sweetness?.Name,
                        ExecutedByUserID = o.ExecutedByUserID,
                        ExecutedByUserFirstName = firstName,     // ✅ ახლა უკვე დაინახავს ცვლადს
                        ExecutedByUserLastName = lastName,       // ✅ ახლა უკვე დაინახავს ცვლადს
                        WeightedAvgDate = o.WeightedAvgDate,
                        IncomingAvgDate = o.IncomingAvgDate, // ✅ დაემატა IncomingAvgDate
                        LinkedOperationID = o.LinkedOperationID,
                        SourceCompanyID = o.SourceCompanyID,
                        SourceBarrelID = o.SourceBarrelID,
                        SourceCompanyName = sourceCompanyName    // ✅ ახლა უკვე დაინახავს ცვლადს
                    };
                }).ToList()
            };

            return View(viewModel);
        }
        [HttpPost]
        [Authorize(Policy = "CanManage")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateSpiritOperationViewModel model)
        {
            try
            {
                model.ExecutedByUserID = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@OperationDefID", model.OperationDefID),
                    new SqlParameter("@BarrelID", model.BarrelID),
                    new SqlParameter("@Quantity", model.Quantity),
                    new SqlParameter("@TransactionDate", model.TransactionDate),
                    new SqlParameter("@WineAlcPercent", (object?)model.WineAlcPercent ?? DBNull.Value),
                    new SqlParameter("@LossPercent", (object?)model.LossPercent ?? DBNull.Value),
                    new SqlParameter("@OppositeBarrelID", (object?)model.OppositeBarrelID ?? DBNull.Value),
                    new SqlParameter("@DocumentNumber", model.DocumentNumber ?? ""),
                    new SqlParameter("@DocumentTypeID", model.DocumentTypeID),
                    new SqlParameter("@ExecutedByUserID", (object?)model.ExecutedByUserID ?? DBNull.Value),
                    // INPUT — არა OUTPUT; ბაზაში @RealPercent უნდა იყოს ჩვეულებრივი პარამეტრი (OUTPUT-ის გარეშე).
                    new SqlParameter("@RealPercent", (object?)model.RealPercent ?? DBNull.Value),
                    new SqlParameter { ParameterName = "@NewOperationID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output },
                    new SqlParameter { ParameterName = "@Message", SqlDbType = SqlDbType.NVarChar, Size = 200, Direction = ParameterDirection.Output }
                };

                // აქ ვიძახებთ სპირტის სპეციალურ პროცედურას!
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC dbo.Spirit_ExecuteOperation @OperationDefID, @BarrelID, @Quantity, @TransactionDate, @WineAlcPercent, @LossPercent, @OppositeBarrelID, @DocumentNumber, @DocumentTypeID, @ExecutedByUserID, @RealPercent, @NewOperationID OUTPUT, @Message OUTPUT",
                    parameters);

                var message = parameters.First(p => p.ParameterName == "@Message").Value?.ToString();
                var newOpIdParam = parameters.First(p => p.ParameterName == "@NewOperationID").Value;
                TempData["Message"] = message;
                var isSuccess = message?.Contains("წარმატ") == true;
                TempData["Status"] = isSuccess ? "success" : "warning";

                if (!isSuccess)
                {
                    TempData["FormData"] = System.Text.Json.JsonSerializer.Serialize(model);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                TempData["Message"] = "შეცდომა ოპერაციის შექმნისას: " + ex.Message;
                TempData["Status"] = "danger";
                TempData["FormData"] = System.Text.Json.JsonSerializer.Serialize(model);
            }

            return RedirectToAction("Index", new { barrelId = model.BarrelID });
        }

        [HttpPost]
        [Authorize(Policy = "CanManage")]
        public async Task<IActionResult> Delete(int operationId)
        {
            // 1. ვპოულობთ კასრის ID-ს რედირექტისთვის
            int? barrelId = await _context.Operations
                .Where(o => o.OperationID == operationId)
                .Select(o => (int?)o.BarrelID)
                .FirstOrDefaultAsync();

            if (barrelId == null)
                return NotFound("ოპერაცია ვერ მოიძებნა.");

            // 2. ვამზადებთ პარამეტრებს ახალი პროცედურისთვის
            int userId = GetCurrentUserId();

            var opIdParam = new SqlParameter("@OperationID", operationId);
            var userIdParam = new SqlParameter("@ExecutedByUserID", userId);
            var batchIdParam = new SqlParameter("@BatchID", DBNull.Value); // ინდივიდუალური წაშლაა, ამიტომ Null
            var msgParam = new SqlParameter("@Message", SqlDbType.NVarChar, 200) { Direction = ParameterDirection.Output };

            try
            {
                // 3. ვიძახებთ განახლებულ პროცედურას
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC dbo.DeleteOperation @OperationID, @ExecutedByUserID, @BatchID, @Message OUTPUT",
                    opIdParam, userIdParam, batchIdParam, msgParam);

                var message = msgParam.Value?.ToString();
                TempData["DeleteMessage"] = message;

                // 4. სტატუსების მართვა შეტყობინების მიხედვით
                if (message != null && (message.Contains("წარმატებით") || message.Contains("დაარქივდა")))
                    TempData["DeleteStatus"] = "success";
                else if (message != null && (message.Contains("ვერ მოიძებნა") || message.Contains("უარყვნილი")))
                    TempData["DeleteStatus"] = "warning";
                else
                    TempData["DeleteStatus"] = "error";
            }
            catch (Exception ex)
            {
                TempData["DeleteMessage"] = "კრიტიკული შეცდომა წაშლისას: " + ex.Message;
                TempData["DeleteStatus"] = "error";
            }

            return RedirectToAction(nameof(Index), new { barrelId = barrelId.Value });
        }

        // --- API მარშრუტები შეცვლილია /api/operations-spirit/... კონფლიქტის ასარიდებლად ---

        [HttpGet("/api/operations-spirit/filtered-companies")]
        public async Task<IActionResult> GetFilteredCompanies(int barrelId)
        {
            var result = new List<SelectListItem>();

            using (var conn = _context.Database.GetDbConnection() as SqlConnection)
            using (var cmd = new SqlCommand("GetFilteredCompanyForTransfer", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BarrelID", barrelId);

                await conn.OpenAsync();
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        result.Add(new SelectListItem
                        {
                            Value = reader["CompanyID"].ToString(),
                            Text = reader["NameWithCount"].ToString()
                        });
                    }
                }
            }

            return Json(result.Select(x => new { value = x.Value, text = x.Text }));
        }

        //1. კასრების ფილტრაციის API(სპირტის ლოგიკით)
        //აქ ვიძახებთ ახალ Spirit_GetFilteredBarrelsForTransfer პროცედურას.

        [HttpGet("/api/operations-spirit/filtered-barrels")]
        public async Task<IActionResult> GetFilteredBarrels(int barrelId, int operType, int? companyId)
        {
            var result = new List<SelectListItem>();

            using (var conn = _context.Database.GetDbConnection() as SqlConnection)
            using (var cmd = new SqlCommand("Spirit_GetFilteredBarrelsForTransfer", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BarrelID", barrelId);
                cmd.Parameters.AddWithValue("@OperType", operType);
                cmd.Parameters.AddWithValue("@OppositeCompanyID", (object?)companyId ?? DBNull.Value);

                await conn.OpenAsync();
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    // 1. წინასწარ ვიგებთ სვეტების პოზიციას (ოპტიმიზაციისთვის)
                    int realPercentIndex = -1;
                    int yearIndex = -1;

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        if (reader.GetName(i) == "RealPercent") realPercentIndex = i;
                        if (reader.GetName(i) == "Year") yearIndex = i;
                    }

                    while (await reader.ReadAsync())
                    {
                        var beverageName = reader["BeverageName"]?.ToString();
                        var volume = reader["CurrentVolume"] != DBNull.Value
                            ? Convert.ToDecimal(reader["CurrentVolume"]).ToString("0.##")
                            : "0";

                        string extraInfo = "";

                        // ✅ თუ სვეტი "RealPercent" არსებობს და მასში მონაცემია (სპირტებისთვის)
                        if (realPercentIndex != -1 && reader[realPercentIndex] != DBNull.Value && Convert.ToDecimal(reader[realPercentIndex]) > 0)
                        {
                            extraInfo = $" ({Convert.ToDecimal(reader[realPercentIndex]).ToString("0.##")}°)";
                        }
                        // ✅ თუ სვეტი "Year" არსებობს და მასში მონაცემია (ღვინის გამოხდისას)
                        else if (yearIndex != -1 && reader[yearIndex] != DBNull.Value)
                        {
                            extraInfo = $" ({reader[yearIndex]})";
                        }

                        result.Add(new SelectListItem
                        {
                            Value = reader["BarrelID"].ToString(),
                            // ✅ ფორმატი: "BeverageName (Year ან RealPercent) - CurrentVolume ლ"
                            Text = $"{beverageName}{extraInfo} - {volume} ლ"
                        });
                    }
                }
            }

            return Json(result.Select(x => new { value = x.Value, text = x.Text }));
        }

        //2. თარიღით მონაცემების წამოღების API(ჭკვიანი ნაშთით)
        //  აქ ვიძახებთ Spirit_Get_Data_By_TransDate - ს,
        //  რომელიც გვიბრუნებს MaxAllowed(მომავლის ლიმიტი)
        //  და WeightedAvgDate(ასაკი) ველებს.

        [HttpGet("/api/operations-spirit/get-data-by-transdate")]
        public async Task<IActionResult> GetDataByTransDate(int operType, int barrelId, int? oppositeBarrelId, DateTime transactionDate)
        {
            int workBarrelId = operType == 1 ? barrelId : oppositeBarrelId ?? 0;

            // --- აი ეს ბლოკი შეცვალე ასე: ---
            if (workBarrelId == 0)
            {
                return Json(new
                {
                    beverageId = 0,
                    beverageName = "",
                    productType = "",
                    category = "",
                    color = "",
                    sweetness = "",
                    volume = 0,
                    maxAllowed = 0,
                    harvestYear = "",
                    weightedAvgDate = "",
                    purePercent = 0,
                    yearLimit = -1,
                    pureLimit = -1,
                    allowMix = false
                });
            }
            // --------------------------------

            // ცვლადების ინიციალიზაცია (აქედან კოდი უცვლელია...)
            int beverageId = 0;
            string beverageName = "";
            string productType = "";
            string category = "";
            string color = "";
            string sweetness = "";
            decimal volume = 0;
            decimal maxAllowed = 0;
            string harvestYear = "";
            string weightedAvgDate = "";
            decimal purePercent = 0;
            decimal yearLimit = -1;
            decimal pureLimit = -1;
            bool allowMix = true;

            using (var conn = _context.Database.GetDbConnection() as SqlConnection)
            using (var cmd = new SqlCommand("Spirit_Get_Data_By_TransDate", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TargetBarrelID", barrelId);
                cmd.Parameters.AddWithValue("@SourceBarrelID", workBarrelId);
                cmd.Parameters.AddWithValue("@OperType", operType);
                cmd.Parameters.AddWithValue("@TransactionDate", transactionDate);

                await conn.OpenAsync();
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        beverageId = Convert.ToInt32(reader["BeverageID"]);
                        beverageName = reader["BeverageName"]?.ToString() ?? "";
                        productType = reader["ProductType"]?.ToString() ?? "";
                        category = reader["Category"]?.ToString() ?? "";
                        color = reader["Color"]?.ToString() ?? "";
                        sweetness = reader["Sweetness"]?.ToString() ?? "";
                        volume = Convert.ToDecimal(reader["Volume"]);
                        maxAllowed = Convert.ToDecimal(reader["MaxAllowed"]);

                        harvestYear = reader["HarvestYear"]?.ToString() ?? "";
                        weightedAvgDate = reader["WeightedAvgDate"] != DBNull.Value ? Convert.ToDateTime(reader["WeightedAvgDate"]).ToString("yyyy-MM-dd") : "";
                        purePercent = Convert.ToDecimal(reader["PurePercent"]);
                        yearLimit = Convert.ToDecimal(reader["YearLimit"]);
                        pureLimit = Convert.ToDecimal(reader["PureLimit"]);
                        allowMix = Convert.ToBoolean(reader["AllowMix"]);
                    }
                }
            }

            return Json(new
            {
                beverageId,
                beverageName,
                productType,
                category,
                color,
                sweetness,
                volume,
                maxAllowed,
                harvestYear,
                weightedAvgDate,
                purePercent,
                yearLimit,
                pureLimit,
                allowMix
            });
        }

        [HttpGet("/api/operations-spirit/document-types")]
        [AllowAnonymous]
        public async Task<IActionResult> GetDocumentTypes()
        {
            try
            {
                var documentTypes = await _context.DocumentTypes
                    .Where(d => d.IsActive)
                    .Select(d => new { value = d.DocumentTypeID, text = d.DocumentName })
                    .ToListAsync();

                return Json(documentTypes);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching document types: {ex.Message}");
                return Json(new List<object>());
            }
        }
    }
}